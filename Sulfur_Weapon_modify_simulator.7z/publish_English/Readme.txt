Installation:
Because the technology used is relatively new, Microsoft official is required .Net8.0 runtime library, when the program is running, there will be a prompt, the safest download from the official website
The folder WindowsDesktop-Run-time 8.0.11-win-x64.exe is the downloaded dependency library
Program entry:
Sulfur_Weapon_modify_simulator.exe